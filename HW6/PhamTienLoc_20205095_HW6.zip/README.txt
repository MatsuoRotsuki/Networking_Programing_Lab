Chạy lệnh sau để biên dịch
$ make

================================
Lần lượt chạy trên terminal khác nhau
$ make start-server
$ make start-client

================================
Để thực hiện truyền file cần có file ảnh ở thư mục mã nguồn
