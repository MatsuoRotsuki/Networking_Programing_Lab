#include <stdio.h>
#include <stdlib.h>

const char *NOT_OK = "Not OK. ";
const char *OK = "Ok. ";
const char *MESSAGE_OK = "Message OK. ";
const char *LOG_OUT = "bye";